var e,o;"function"==typeof(e=globalThis.define)&&(o=e,e=null),function(o,t,n,i,r){var a="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:"undefined"!=typeof window?window:"undefined"!=typeof global?global:{},d="function"==typeof a[i]&&a[i],l=d.cache||{},s="undefined"!=typeof module&&"function"==typeof module.require&&module.require.bind(module);function c(e,t){if(!l[e]){if(!o[e]){var n="function"==typeof a[i]&&a[i];if(!t&&n)return n(e,!0);if(d)return d(e,!0);if(s&&"string"==typeof e)return s(e);var r=Error("Cannot find module '"+e+"'");throw r.code="MODULE_NOT_FOUND",r}p.resolve=function(t){var n=o[e][1][t];return null!=n?n:t},p.cache={};var g=l[e]=new c.Module(e);o[e][0].call(g.exports,p,g,g.exports,this)}return l[e].exports;function p(e){var o=p.resolve(e);return!1===o?{}:c(o)}}c.isParcelRequire=!0,c.Module=function(e){this.id=e,this.bundle=c,this.exports={}},c.modules=o,c.cache=l,c.parent=d,c.register=function(e,t){o[e]=[function(e,o){o.exports=t},{}]},Object.defineProperty(c,"root",{get:function(){return a[i]}}),a[i]=c;for(var g=0;g<t.length;g++)c(t[g]);if(n){var p=c(n);"object"==typeof exports&&"undefined"!=typeof module?module.exports=p:"function"==typeof e&&e.amd?e(function(){return p}):r&&(this[r]=p)}}({"9ScAo":[function(e,o,t){var n=e("@parcel/transformer-js/src/esmodule-helpers.js");n.defineInteropFlag(t),n.export(t,"config",()=>i);let i={matches:["<all_urls>"],run_at:"document_idle",all_frames:!0},r=/[\uac00-\ud7a3]+(?:\ub85c|\uae38)\s*\d+|[\uac00-\ud7a3]+(?:\ub3d9|\ub9ac)\s+\d+|[\uac00-\ud7a3]+(?:\uad6c|\uc2dc|\uad70)\s+[\uac00-\ud7a3]+(?:\ub85c|\uae38|\ub3d9)|[\uac00-\ud7a3]+\ubc88\uc9c0/,a=null,d=null,l=null,s=null,c=null,g="",p={road:"\ub3c4\ub85c\uba85",jibun:"\uc9c0\ubc88",admin:"\ud589\uc815\ub3d9",postal:"\uc6b0\ud3b8",coord:"\uc88c\ud45c"},f={road:!0,jibun:!0,admin:!0,postal:!1,coord:!1};try{chrome.storage?.local?.get("inlineCardToggles",e=>{e?.inlineCardToggles&&(f={...f,...e.inlineCardToggles})})}catch{}function u(){if(s)return s;(l=document.createElement("div")).id="gjdong-inline-host",l.style.cssText="position:absolute;top:0;left:0;z-index:2147483647;pointer-events:none;",document.body.appendChild(l),s=l.attachShadow({mode:"closed"});let e=document.createElement("style");return e.textContent=$,s.appendChild(e),s}function h(){c&&(clearTimeout(c),c=null),a?.remove(),a=null}function x(){d?.remove(),d=null}function m(){h(),x()}function b(e,o){let t;x(),h();let n=u();(d=document.createElement("div")).className="gjdong-card",d.innerHTML=`
    <div class="gjdong-body">
      <div class="gjdong-skeleton-title"></div>
      <div class="gjdong-skeleton-chips"></div>
      <div class="gjdong-skeleton-row"></div>
      <div class="gjdong-skeleton-row short"></div>
    </div>
  `;let i=window.scrollX,r=window.scrollY,a=window.innerWidth,l=window.innerHeight,s=e.left+i,c=l-e.bottom,g=e.top;c<196&&g>c?(t=e.top+r-180-10,d.classList.add("above")):t=e.bottom+r+10,s+320>i+a-12&&(s=i+a-320-12),s<i+8&&(s=i+8);let b=e.left+e.width/2+i,$=b-s;$=Math.max(16,Math.min($,304)),d.style.setProperty("--arrow-x",`${$}px`),d.style.left=`${s}px`,d.style.top=`${t}px`,d.addEventListener("click",e=>e.stopPropagation()),n.appendChild(d);let C=t=>{if(d){if(t?.error)v(t.error);else if(t?.result&&(function(e,o){let t=d?.querySelector(".gjdong-body");if(!t)return;if(e.fallback){v(`"${o}" \uacb0\uacfc \uc5c6\uc74c`);return}let{meta:n}=e,i=n.sido?`${n.sido} ${e.display}`:e.display,r={road:"",jibun:"",admin:"",postal:"",coord:""};n.roadName&&(r.road=n.buildingNo?n.unit?`${n.gu} ${n.roadName} ${n.buildingNo} ${n.unit}`:`${n.gu} ${n.roadName} ${n.buildingNo}`:`${n.gu} ${n.roadName}`),n.legalDong&&(r.jibun=`${n.gu} ${n.legalDong} ${n.jibunNo||""}`),n.adminDong&&(r.admin=n.adminDong),n.postalCode&&(r.postal=n.postalCode),n.lat&&n.lon&&(r.coord=`${n.lat.toFixed(6)}, ${n.lon.toFixed(6)}`);let a=`https://gjdong.vercel.app/?q=${encodeURIComponent(o)}`;t.innerHTML=`
    <div class="gjdong-header">
      <div class="gjdong-title" data-v="${k(i)}">${j(i)}</div>
      <div class="gjdong-actions">
        <button class="gjdong-action-btn gjdong-copy-title" title="\uc8fc\uc18c \ubcf5\uc0ac" data-v="${k(i)}">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
        </button>
        <a class="gjdong-action-btn" href="${a}" target="_blank" rel="noopener" title="\uc6f9\uc571\uc5d0\uc11c \uc5f4\uae30">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
        </a>
        <button class="gjdong-action-btn gjdong-close-btn" title="\ub2eb\uae30">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
        </button>
      </div>
    </div>
    <div class="gjdong-chips">
      ${Object.keys(p).filter(e=>r[e]).map(e=>`
        <button class="gjdong-chip ${f[e]?"active":""}" data-field="${e}">${p[e]}</button>
      `).join("")}
    </div>
    <div class="gjdong-rows">
      ${Object.keys(p).filter(e=>r[e]).map(e=>`
        <div class="gjdong-row ${f[e]?"":"hidden"}" data-field="${e}">
          <span class="gjdong-label">${p[e]}</span>
          <span class="gjdong-value">${j(r[e])}</span>
          <button class="gjdong-copy" data-v="${k(r[e])}">
            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
          </button>
        </div>
      `).join("")}
    </div>
    <div class="gjdong-footer">
      <a class="gjdong-map" href="https://map.naver.com/p/search/${encodeURIComponent(i)}" target="_blank" rel="noopener">
        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
        \uc9c0\ub3c4
      </a>
    </div>
  `,t.querySelector(".gjdong-close-btn")?.addEventListener("click",e=>{e.stopPropagation(),m()}),t.querySelector(".gjdong-copy-title")?.addEventListener("click",e=>{e.stopPropagation();let o=e.currentTarget;y(o.dataset.v||""),w(o)}),t.querySelectorAll(".gjdong-chip").forEach(e=>{e.addEventListener("click",o=>{o.stopPropagation();let n=e.dataset.field;f[n]=!f[n],e.classList.toggle("active"),function(){try{chrome.storage?.local?.set({inlineCardToggles:f})}catch{}}();let i=t.querySelector(`.gjdong-row[data-field="${n}"]`);i&&(f[n]?i.classList.remove("hidden"):i.classList.add("hidden"))})}),t.querySelectorAll(".gjdong-copy").forEach(e=>{e.addEventListener("click",async o=>{o.stopPropagation(),y(e.dataset.v||""),w(e)})})}(t.result,o),d?.classList.contains("above"))){let o=d.offsetHeight;d.style.top=`${e.top+r-o-10}px`}}},T=(e=0)=>{if(!chrome.runtime?.id){if(e<2){setTimeout(()=>T(e+1),300);return}v("\uc775\uc2a4\ud150\uc158 \uc7ac\uc5f0\uacb0 \ud544\uc694 \u2014 \ud398\uc774\uc9c0\ub97c \uc0c8\ub85c\uace0\uce68 \ud574\uc8fc\uc138\uc694");return}chrome.runtime.sendMessage({type:"inline-resolve-address",address:o}).then(C).catch(o=>{if(e<1){setTimeout(()=>T(e+1),500);return}v("\uc11c\ubc84 \uc5f0\uacb0 \uc2e4\ud328")})};T()}function v(e){let o=d?.querySelector(".gjdong-body");o&&(o.innerHTML=`<div class="gjdong-error">${e}</div>`)}async function y(e){try{await navigator.clipboard.writeText(e)}catch{let o=document.createElement("textarea");o.value=e,o.style.cssText="position:fixed;opacity:0",document.body.appendChild(o),o.select(),document.execCommand("copy"),document.body.removeChild(o)}}function w(e){let o=e.innerHTML;e.classList.add("copied"),e.innerHTML='<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>',setTimeout(()=>{e.classList.remove("copied"),e.innerHTML=o},800)}function j(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function k(e){return j(e).replace(/'/g,"&#39;")}document.addEventListener("mouseup",e=>{e.target?.closest?.("#gjdong-inline-host")||setTimeout(()=>{let e=window.getSelection(),o=e?.toString()?.trim();if(!o||o.length<4||o.length>200||!r.test(o)){h();return}let t=e?.getRangeAt(0);if(!t)return;let n=t.getBoundingClientRect();(0!==n.width||0!==n.height)&&function(e,o){h(),x(),g=o;let t=u();(a=document.createElement("div")).className="gjdong-trigger",a.innerHTML='<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>';let n=window.scrollX,i=window.scrollY;a.style.left=`${e.right+n+4}px`,a.style.top=`${e.top+i+(e.height-24)/2}px`,a.addEventListener("click",o=>{o.stopPropagation(),o.preventDefault(),b(e,g)}),a.addEventListener("mouseenter",()=>{c&&(clearTimeout(c),c=null)}),t.appendChild(a),c=setTimeout(()=>{h()},5e3)}(n,o)},10)},!0),document.addEventListener("mousedown",e=>{if(!d&&!a)return;let o=e.target;o===l||l?.contains(o)||m()},!0),document.addEventListener("keydown",e=>{"Escape"===e.key&&m()},!0),chrome.runtime?.onMessage?.addListener(e=>{if("show-inline-card"===e.type&&e.address){let o=window.getSelection();if(o&&o.rangeCount>0){let t=o.getRangeAt(0).getBoundingClientRect();if(t.width>0||t.height>0){b(t,e.address);return}}b(new DOMRect(window.innerWidth/2-160,window.innerHeight/3,0,0),e.address)}});let $=`
  * { box-sizing: border-box; margin: 0; padding: 0; }

  .gjdong-trigger {
    position: absolute;
    pointer-events: auto;
    width: 24px; height: 24px;
    display: flex; align-items: center; justify-content: center;
    background: #fff;
    border: 1px solid #e0e0e0;
    border-radius: 50%;
    cursor: pointer;
    color: #5B5FC7;
    box-shadow: 0 1px 4px rgba(0,0,0,.12);
    transition: all .15s ease;
    animation: pop .2s cubic-bezier(.34,1.56,.64,1);
  }
  .gjdong-trigger:hover {
    background: #5B5FC7; color: #fff; border-color: #5B5FC7;
    box-shadow: 0 2px 8px rgba(91,95,199,.35);
    transform: scale(1.08);
  }
  @keyframes pop {
    0% { opacity:0; transform:scale(.4); }
    100% { opacity:1; transform:scale(1); }
  }

  .gjdong-card {
    position: absolute;
    pointer-events: auto;
    width: 320px;
    background: #fff;
    border: 1px solid #e6e6e6;
    border-radius: 10px;
    box-shadow: 0 4px 24px rgba(0,0,0,.10), 0 1px 3px rgba(0,0,0,.06);
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;
    font-size: 13px;
    color: #222;
    overflow: visible;
    animation: cardIn .18s ease-out;
  }
  @keyframes cardIn {
    0% { opacity:0; transform:translateY(-4px) scale(.98); }
    100% { opacity:1; transform:translateY(0) scale(1); }
  }
  /* \ub9d0\ud48d\uc120 \uaf2c\ub9ac - \uc544\ub798\ub85c \uc5f4\ub9b4 \ub54c (\uc704\ucabd \uaf2c\ub9ac) */
  .gjdong-card::before {
    content: "";
    position: absolute;
    top: -6px;
    left: var(--arrow-x, 24px);
    transform: translateX(-50%);
    width: 12px; height: 6px;
    background: #fff;
    clip-path: polygon(50% 0%, 0% 100%, 100% 100%);
    filter: drop-shadow(0 -1px 1px rgba(0,0,0,.06));
  }
  .gjdong-card::after {
    content: "";
    position: absolute;
    top: -7px;
    left: var(--arrow-x, 24px);
    transform: translateX(-50%);
    width: 14px; height: 7px;
    background: #e6e6e6;
    clip-path: polygon(50% 0%, 0% 100%, 100% 100%);
    z-index: -1;
  }

  /* \uc704\ub85c \uc5f4\ub9b4 \ub54c (\uc544\ub798\ucabd \uaf2c\ub9ac) */
  .gjdong-card.above::before {
    top: auto; bottom: -6px;
    clip-path: polygon(0% 0%, 100% 0%, 50% 100%);
    filter: drop-shadow(0 1px 1px rgba(0,0,0,.06));
  }
  .gjdong-card.above::after {
    top: auto; bottom: -7px;
    clip-path: polygon(0% 0%, 100% 0%, 50% 100%);
  }

  .gjdong-card.above {
    animation: cardInAbove .18s ease-out;
  }
  @keyframes cardInAbove {
    0% { opacity:0; transform:translateY(4px) scale(.98); }
    100% { opacity:1; transform:translateY(0) scale(1); }
  }

  .gjdong-body { padding: 10px 12px 8px; overflow: hidden; border-radius: 10px; }

  /* \uc2a4\ucf08\ub808\ud1a4 */
  .gjdong-skeleton-title {
    height: 14px; width: 75%; border-radius: 3px;
    background: linear-gradient(90deg, #f0f0f0 25%, #e4e4e4 50%, #f0f0f0 75%);
    background-size: 200% 100%;
    animation: shimmer 1.2s infinite;
    margin-bottom: 8px;
  }
  .gjdong-skeleton-chips {
    height: 10px; width: 60%; border-radius: 3px;
    background: linear-gradient(90deg, #f0f0f0 25%, #e4e4e4 50%, #f0f0f0 75%);
    background-size: 200% 100%;
    animation: shimmer 1.2s infinite;
    margin-bottom: 8px;
  }
  .gjdong-skeleton-row {
    height: 10px; width: 90%; border-radius: 3px;
    background: linear-gradient(90deg, #f0f0f0 25%, #e4e4e4 50%, #f0f0f0 75%);
    background-size: 200% 100%;
    animation: shimmer 1.2s infinite;
    margin-bottom: 6px;
  }
  .gjdong-skeleton-row.short { width: 45%; }
  @keyframes shimmer {
    0% { background-position: 200% 0; }
    100% { background-position: -200% 0; }
  }

  /* \ud5e4\ub354 */
  .gjdong-header {
    display: flex;
    align-items: flex-start;
    gap: 6px;
    padding-bottom: 7px;
    border-bottom: 1px solid #f0f0f0;
    margin-bottom: 6px;
  }
  .gjdong-title {
    flex: 1;
    font-size: 12.5px;
    font-weight: 600;
    color: #111;
    line-height: 1.45;
    word-break: keep-all;
  }
  .gjdong-actions {
    display: flex;
    align-items: center;
    gap: 2px;
    flex-shrink: 0;
    margin-top: 1px;
  }
  .gjdong-action-btn {
    width: 24px; height: 24px;
    display: flex; align-items: center; justify-content: center;
    background: none; border: none;
    cursor: pointer; color: #bbb;
    border-radius: 5px;
    transition: all .12s;
    text-decoration: none;
  }
  .gjdong-action-btn:hover { background: #f2f2f3; color: #5B5FC7; }
  .gjdong-action-btn.copied { color: #22c55e; }

  /* \ud1a0\uae00 \uce69 */
  .gjdong-chips {
    display: flex;
    flex-wrap: wrap;
    gap: 4px;
    margin-bottom: 6px;
  }
  .gjdong-chip {
    display: inline-flex;
    align-items: center;
    height: 22px;
    padding: 0 8px;
    font-size: 11px;
    font-family: inherit;
    border-radius: 11px;
    cursor: pointer;
    transition: all .15s ease;
    border: 1px solid #e0e0e0;
    background: #fff;
    color: #aaa;
    user-select: none;
    line-height: 1;
  }
  .gjdong-chip:hover {
    border-color: #c8c8d0;
    color: #666;
  }
  .gjdong-chip.active {
    background: #5B5FC7;
    border-color: #5B5FC7;
    color: #fff;
  }
  .gjdong-chip.active:hover {
    background: #4F53B8;
    border-color: #4F53B8;
    color: #fff;
  }

  /* \uacb0\uacfc \ud589 */
  .gjdong-rows { display: flex; flex-direction: column; gap: 0; }
  .gjdong-row {
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 4px 4px;
    border-radius: 4px;
    transition: background .1s, max-height .2s ease, opacity .15s ease, padding .2s ease;
    max-height: 36px;
    overflow: hidden;
    opacity: 1;
  }
  .gjdong-row.hidden {
    max-height: 0;
    opacity: 0;
    padding-top: 0;
    padding-bottom: 0;
    pointer-events: none;
  }
  .gjdong-row:hover { background: #f7f7f8; }
  .gjdong-label {
    flex-shrink: 0;
    font-size: 10.5px;
    color: #999;
    width: 36px;
    text-align: right;
  }
  .gjdong-value {
    flex: 1;
    font-size: 12px;
    color: #333;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .gjdong-copy {
    flex-shrink: 0;
    background: none; border: none;
    cursor: pointer; color: #ccc;
    width: 22px; height: 22px;
    display: flex; align-items: center; justify-content: center;
    border-radius: 4px;
    transition: all .12s;
  }
  .gjdong-copy:hover { background: #ededf0; color: #5B5FC7; }
  .gjdong-copy.copied { color: #22c55e; }

  /* \ud478\ud130 */
  .gjdong-footer {
    display: flex;
    align-items: center;
    padding: 4px 4px 2px;
    margin-top: 2px;
  }
  .gjdong-map {
    display: inline-flex; align-items: center; gap: 3px;
    font-size: 10.5px; color: #999; text-decoration: none;
    transition: color .12s;
    padding: 2px 4px;
    border-radius: 4px;
  }
  .gjdong-map:hover { color: #5B5FC7; background: #f7f7f8; }

  .gjdong-error {
    font-size: 12px; color: #999;
    padding: 6px 0;
  }
`},{"@parcel/transformer-js/src/esmodule-helpers.js":"fRZO2"}],fRZO2:[function(e,o,t){t.interopDefault=function(e){return e&&e.__esModule?e:{default:e}},t.defineInteropFlag=function(e){Object.defineProperty(e,"__esModule",{value:!0})},t.exportAll=function(e,o){return Object.keys(e).forEach(function(t){"default"===t||"__esModule"===t||o.hasOwnProperty(t)||Object.defineProperty(o,t,{enumerable:!0,get:function(){return e[t]}})}),o},t.export=function(e,o,t){Object.defineProperty(e,o,{enumerable:!0,get:t})}},{}]},["9ScAo"],"9ScAo","parcelRequire6b3c"),globalThis.define=o;